// Alex Chandarana Copyright 2024

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class FileIOSolutions {
	
	public static void pastTense(String input, String output) {
		File ItIs = new File(input);
		File ItWas = new File(output);
		PrintWriter writer = null;
		Scanner counter = null;
		Scanner reader = null;
		
		try { // Auto generated syntax for "try," "catch," and "finally." This is necessary for the code to run.
			writer = new PrintWriter(ItWas);
			reader = new Scanner(ItIs);
			counter = new Scanner(ItIs);
			int count = 0;
			while (counter.hasNext()) {
				counter.next();
				count++;
			}
			
			String[] tenseWords = new String[count];
			
			for (int i = 0; i < count; i++) {
				tenseWords[i] = reader.next();
			}
			for (int i = 0; i < count; i++) {
				if(tenseWords[i].equals("is") || tenseWords[i].equals("Is")) { // ensures case doesn't matter
					tenseWords[i] = "was";
				}
				// adds results to both console and text file
				System.out.println(tenseWords[i]);
				writer.println(tenseWords[i]);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (writer != null) {
				writer.close();
			}
		}
	}

	public static double totalTubeVolume(String input) {
		File Tubes = new File(input);
		Scanner reader = null;
		double tVolume = 0;
		double pi = Math.PI;
		
		try {
			reader = new Scanner(Tubes); // if tree ensure formatting is correct, skips over volume calculation if not
			for (int i = 0; i < 100; i++) {
				String id = null;
				if(reader.hasNext()) id = reader.next();
				if(reader.hasNextInt()) {
					int idNum = reader.nextInt();
					if(reader.hasNextDouble()) {
						double rad = reader.nextDouble();
						if(reader.hasNextDouble()) {
							// Calculates volume and adds it to total here
							double high = reader.nextDouble();
							double vol = pi*rad*rad*high; // rad twice for radius squared
							tVolume += vol;
						}
					}
				}
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			if(reader != null) {
				reader.close();
			}
		}
		return tVolume;
	}

}
