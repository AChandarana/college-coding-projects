// Copyright 2025 Alex Chandarana
#ifndef HEIGHTRANGE_H_
#define HEIGHTRANGE_H_
#include "height.h"

class HeightRange {
 public:
  // Sets a height to be the shortest height.
  // If the tallest height is more than the height, it does not update.
  void SetShortest(const Height &);

  // Returns a copy of the Height that is marked as the shortest
  Height GetShortest() const;

  // Sets a height to be the tallest height
  // If the shortest hight is smaller than the height, it does not update.
  void SetTallest(const Height &);

  // Returns a copy of the tallest Height
  Height GetTallest() const;

  // Returns true if the height is within the tallest and shortest.
  // If it's outside that range, returns false.
  bool InRange(const Height &, const bool = true) const;

  // Constructor
  HeightRange(const Height &shortest, const Height &tallest);

  HeightRange();

  // Returns a Height representing the difference between the tallest and
  // shortest in the range. The units return match the units of the tallest.
  Height Width() const;

 private:
  Height shortest_;
  Height tallest_;
};

#endif
