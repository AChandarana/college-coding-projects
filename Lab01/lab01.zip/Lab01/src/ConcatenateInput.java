// Alex Chandarana

import java.util.Scanner;

public class ConcatenateInput {

    public static void main(String[] args) {
        
    	int int1, int2, int3;
    	double double1, double2, double3;
		String string1, string2, string3;
    	
    	Scanner stdin = new Scanner(System.in);
        
    	int1 = stdin.nextInt();
    	int2 = stdin.nextInt();
    	double1 = stdin.nextDouble();
    	double2 = stdin.nextDouble(); // I don't need the doubles here, but I'm not sure how to get the code to run without these lines here
    	double3 = stdin.nextDouble();
    	string1 = stdin.next();
    	string2 = stdin.next();
    	string3 = stdin.next();
    	int3 = stdin.nextInt();
    	
    	System.out.println(string1 + string2 + string3 + (int1 + int2 + int3));
    }

}
