// Copyright 2025 Alex Chandarana
#include "height.h"
#include <cmath>
#include <iostream>

static double ToMeters(double v, const string &u) {
  if (u == "inches")
    return v * 0.0254;
  if (u == "feet")
    return v * 0.3048;
  if (u == "centimeters")
    return v * 0.01;
  return v;
}

static double FromMeters(double meters, const string &u) {
  if (u == "inches")
    return meters / 0.0254;
  if (u == "feet")
    return meters / 0.3048;
  if (u == "centimeters")
    return meters * 100.0;
  return meters;
}

Height::Height(const double value, const string &unit) {
  if (!SetValue(value)) {
    value_ = 0;
  }
  if (!SetUnits(unit)) {
    unit_ = "feet";
  }
}

bool Height::SetValue(const double value) {
  if (value < 0)
    return false;
  value_ = value;
  return true;
}

double Height::GetValue() const { return value_; }

bool Height::SetUnits(const string &u) {
  if (u == "feet" || u == "meters" || u == "inches" || u == "centimeters") {
    unit_ = u;
    return true;
  }
  return false;
}

string Height::GetUnits() const { return unit_; }

bool Height::ConvertUnits(const string &u) {
  if (!(u == "feet" || u == "meters" || u == "inches" || u == "centimeters"))
    return false;
  const double meters = ToMeters(value_, unit_);
  value_ = FromMeters(meters, u);
  unit_ = u;
  return true;
}

bool operator==(const Height &a, const Height &b) {
  const double am = ToMeters(a.GetValue(), a.GetUnits());
  const double bm = ToMeters(b.GetValue(), b.GetUnits());
  return std::fabs(am - bm) < 1e-9;
}

bool operator<(const Height &a, const Height &b) {
  const double am = ToMeters(a.GetValue(), a.GetUnits());
  const double bm = ToMeters(b.GetValue(), b.GetUnits());
  return am < bm;
}

std::ostream &operator<<(std::ostream &out, const Height &h) {
  out << h.GetValue() << " " << h.GetUnits();
  return out;
}
