// Copyright 2025 Alex Chandarana
#include "heightrange.h"

HeightRange::HeightRange(const Height &shortest, const Height &tallest) {
  if (shortest <= tallest) {
    shortest_ = shortest;
    tallest_ = tallest;
  } else {
    shortest_ = tallest;
    tallest_ = shortest;
  }
}

HeightRange::HeightRange() {
  shortest_ = Height(0, "feet");
  tallest_ = Height(0, "feet");
}

void HeightRange::SetShortest(const Height &shortest) {
  if (shortest <= tallest_) {
    shortest_ = shortest;
  }
}

void HeightRange::SetTallest(const Height &tallest) {
  if (shortest_ <= tallest) {
    tallest_ = tallest;
  }
}

Height HeightRange::GetShortest() const { return shortest_; }

Height HeightRange::GetTallest() const { return tallest_; }

bool HeightRange::InRange(const Height &h, const bool edge) const {
  if (edge) {
    if (h >= shortest_ && h <= tallest_) {
      return true;
    }
  } else {
    if (h > shortest_ && h < tallest_) {
      return true;
    }
  }
  return false;
}

Height HeightRange::Width() const {
  Height s = shortest_;
  s.ConvertUnits(tallest_.GetUnits());
  double diff = tallest_.GetValue() - s.GetValue();
  if (diff < 0)
    diff = 0;
  return Height(diff, tallest_.GetUnits());
}
