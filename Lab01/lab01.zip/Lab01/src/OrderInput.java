// Alex Chandarana

import java.util.Scanner;

public class OrderInput {

    public static void main(String[] args) {
        
    	int int1, int2, int3;
    	double double1, double2, double3;
		String string1, string2, string3;
    	
    	Scanner stdin = new Scanner(System.in);
        
    	int1 = stdin.nextInt();
    	int2 = stdin.nextInt();
    	double1 = stdin.nextDouble();
    	double2 = stdin.nextDouble();
    	double3 = stdin.nextDouble();
    	string1 = stdin.next();
    	string2 = stdin.next();
    	string3 = stdin.next();
    	int3 = stdin.nextInt();
    	
    	System.out.println(string1);
        System.out.println(string2);
        System.out.println(string3);
        System.out.println(int1);
        System.out.println(int2);
        System.out.println(int3);
        System.out.println(double1);
        System.out.println(double2);
        System.out.println(double3);
    }

}
