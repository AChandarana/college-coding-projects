// Copyright 2025 Alex Chandarana

public class DoubleDoubleLL {
	private class ListNode {
		double data;
		ListNode linkP, linkN;
		public ListNode(double d, ListNode l1, ListNode l2){
			data = d;
			linkP = l1;
			linkN = l2;
		}
	}
	private ListNode head, current, tail;
	private int size; // for creating arrays for easier sorting etc
	public DoubleDoubleLL() {
		head = current = null;
		this.size = 0;
	}
	public void add(double d) {
		if(head == null) head = tail = current = new ListNode(d, null, null);
		else {
			ListNode temp = new ListNode(d, tail, null);
			tail.linkN = temp; // adds onto the tail
			tail = temp; // moves the tail
		}
		this.size++;
	}
	
	public void addAfterCurrent(double d) {
		if (current == null) return; // for the case of an empty list
		if (current.linkN == null) return; // if reference is null
		ListNode nNode = new ListNode(d, current, current.linkN);
		current.linkN.linkP = nNode;
		current.linkN = nNode;
		this.size++; // increases size for array
	}
	
	public void gotoNext() {
		if (current != null) current = current.linkN;
	}
	
	public void gotoPrev() {
		if (current != null) current = current.linkP;
	}
	
	public void reset() {
		current = head;
	}
	
	public boolean hasMore() {
		return (current != null);
	}
	
	public int getSize() {
		return this.size;
	}
	public void print() {
		ListNode temp = head;
		while (temp != null) {
			System.out.println(temp.data);
			temp = temp.linkN;
		}
	}
	public double getCurrent() {
		return current.data;
	}
	
	public void setCurrent(double d) {
		current.data = d;
	}
	
	public void removeCurrent() {
		if(current == null) return;
		if(current.linkP == null && current.linkN == null) { // Only 1 item exists
			current = head = tail = null;
			return;
		}
		if(current.linkP == null) { // remove head
			head = head.linkN;
			head.linkP = null;
			current = head;
			return;
		}
		if(current.linkN == null) { // remove tail
			tail = tail.linkP;
			tail.linkN = null;
			current = tail;
			return;
		}
		current.linkP.linkN = current.linkN;
		current.linkN.linkP = current.linkP;
		current = current.linkN;
		size--;
	}
	
	public void remove(double d) {
		ListNode temp = head;
		while (temp != null && temp.data != d) {
			temp = temp.linkN;
		}
		if (temp != null) {
			current = temp;
			removeCurrent();
		}
	}
	
	public void gotoEnd() {
		if(tail != null) current = tail;
	}
	
	public boolean contains(double d) {
		ListNode temp = head;
		while(temp != null) {
			if (temp.data == d) return true;
			temp = temp.linkN;
		}
		return false;
	}
}
