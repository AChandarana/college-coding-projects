// Copyright 2025 Alex Chandarana
#ifndef HEIGHT_H_
#define HEIGHT_H_

#include <iosfwd>
#include <string>
using std::string;

class Height {
 public:
  // Default height constructor
  explicit Height(double value = 0, const string &unit = "feet");

  // Sets the value data member to the argument's value as long as the value is
  // positive. If the value is negative, it does not set the value. Returns true
  // if it sets the value, false if it doesn't.
  bool SetValue(double value);

  // Returns a copy of the value data member
  double GetValue() const;

  // Sets the unit data member to the string as long as it's in, ft, cm, or m.
  // If it sets the string, returns true. If not, returns false.
  bool SetUnits(const string &unit);

  // Returns a copy of the unit data member
  string GetUnits() const;

  // Converts one unit to another if the argument is valid.
  // If it makes the change, returns true, otherwise returns false.
  bool ConvertUnits(const string &unit);

 private:
  double value_;
  string unit_;
};

bool operator==(const Height &a, const Height &b);
bool operator<(const Height &a, const Height &b);
inline bool operator!=(const Height &a, const Height &b) { return !(a == b); }
inline bool operator<=(const Height &a, const Height &b) {
  return (a < b) || (a == b);
}
inline bool operator>(const Height &a, const Height &b) { return b < a; }
inline bool operator>=(const Height &a, const Height &b) {
  return (b < a) || (a == b);
}
std::ostream &operator<<(std::ostream &out, const Height &h);

#endif
