// Copyright 2025 Alex Chandarana
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class Liner {
	
	public static String linePrizeName(String line) {
		String prizeName = "";
		String[] split = line.split("\t");
		if (split.length == 2) {
			prizeName = split[0];
		} else return null;
        
		// Makes sure the value after the prize name is an integer
		try {
			Integer.parseInt(split[1].trim());
			return prizeName;
		} catch (NumberFormatException e) {
			return null;
		}
	}
		
	public static int linePrizeCost(String line) {
		int prizeCost = 0;
		String[] split = line.split("\t");
		if (split.length != 2) {
			return -1; // PrizeDrive will have condition that anything not >= 0 is ignored
		} 
        
		// Makes sure the value after the prize name is an integer
		try {
			Integer.parseInt(split[1].trim());
			return Integer.parseInt(split[1].trim());
		} catch (NumberFormatException e) {
			return -1;
		}
	}
	
	public static String[] nameArrayer(String fileName) {
		File Prizes = new File("./" + fileName);
		Scanner lineSeekC = null;
		Scanner lineSeek = null;
		try {
			lineSeekC = new Scanner(Prizes);
			lineSeek = new Scanner(Prizes);
			int cnt = 0;
			while (lineSeekC.hasNextLine()) { // Counts amount in list
				String prizeName = Liner.linePrizeName(lineSeekC.nextLine());
				if (prizeName != null) {
					cnt++;
				}
			}
			String[] prizeNames = new String[cnt];
			int inc = 0;
			while (lineSeek.hasNextLine()) { // Creates the array
				String prizeName = Liner.linePrizeName(lineSeek.nextLine());
				if (prizeName != null) {
					prizeNames[inc] = prizeName;
					++inc;
				}
			}
			lineSeek.close();
			lineSeekC.close();
			return prizeNames;
		} catch (FileNotFoundException e) {
			return null;
		}
	}
	
	public static double[] costArrayer(String fileName) {
		File Prizes = new File("./" + fileName);
		Scanner lineSeekC = null;
		Scanner lineSeek = null;
		try {
			lineSeekC = new Scanner(Prizes);
			lineSeek = new Scanner(Prizes);
			int cnt = 0;
			while (lineSeekC.hasNextLine()) {
				double prizeCost = Liner.linePrizeCost(lineSeekC.nextLine());
				if (prizeCost != -1) {
					cnt++;
				}
			}
			double[] prizeCosts = new double[cnt];
			int inc = 0;
			while (lineSeek.hasNextLine()) {
				int prizeCost = Liner.linePrizeCost(lineSeek.nextLine());
				if (prizeCost != -1) {
					prizeCosts[inc] = prizeCost;
					++inc;
				}
			}
			lineSeek.close();
			lineSeekC.close();
			return prizeCosts;
		} catch (FileNotFoundException e) {
			return null;
		}
	}
}
