// Alex Chandarana

import java.util.Scanner;

public class MultiplyDoubles {

    public static void main(String[] args) {
        
    	double double1, double2;
		String string1, string2, string3, string4, string5;
    	
    	Scanner stdin = new Scanner(System.in);
        
    	double1 = stdin.nextDouble();
    	string1 = stdin.next();
    	string2 = stdin.next();
    	string3 = stdin.next();
    	string4 = stdin.next();
    	string5 = stdin.next();
    	double2 = stdin.nextDouble();
    	
    	System.out.println(string1 + " " + string2 + " " +  string4 + " " +  string5 + " " +  (double1*double2));
    }

}
