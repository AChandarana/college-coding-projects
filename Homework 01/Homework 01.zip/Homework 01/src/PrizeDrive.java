// Copyright 2025 Alex Chandarana
import java.util.Scanner;
import java.util.Random;
public class PrizeDrive {

	public static void main(String[] args) {
		// This chunk initiates everything
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Enter the name of the file with the prizes: \t");
		String fileName = keyboard.next();
		String[] prizeNames = Liner.nameArrayer(fileName);
		double[] prizeCosts = Liner.costArrayer(fileName);
		System.out.println("File selected: " + fileName + "\n");
		boolean playAgain = true;
		
		
		while(playAgain) {
			// This selects the random items and makes sure they don't repeat
			Random random = new Random();
			int p1=0, p2=0, p3=0, p4=0, p5=0;
			p1 = random.nextInt(prizeNames.length);
			while (p2 == p1) {
				p2 = random.nextInt(prizeNames.length);
			}
			while (p3 == p1 || p3 == p2) {
				p3 = random.nextInt(prizeNames.length);
			}
			while (p4 == p1 || p4 == p2 || p4 == p3) {
				p4 = random.nextInt(prizeNames.length);
			}
			while (p5 == p1 || p5 == p2 || p5 == p3 || p5 == p4) {
				p5 = random.nextInt(prizeNames.length);
			}
			// Calculates cost of teh random items
			double actualCost = prizeCosts[p1] + prizeCosts[p2] + prizeCosts[p3] + prizeCosts[p4] + prizeCosts[p5];
			System.out.println("Welcome to Showcase: A completely orginial gameshow!\nLet's begin! Your prizes are:\n- "
					+ prizeNames[p1] + "\n- "
					+ prizeNames[p2] + "\n- "
					+ prizeNames[p3] + "\n- "
					+ prizeNames[p4] + "\n- "
					+ prizeNames[p5] + "\n");
			System.out.println("What is your guess of the cost? Remember:\n"
					+ "-\tYou must be within $1300 of the correct cost\n"
					+ "-\tYou cannot go over the correct cost\n"
					+ "-\tYour guess must be a number");
			double guess = keyboard.nextDouble();
			System.out.println("\nYour guess: \t$" + guess + "\n"
					+ "Actual cost:\t$" + actualCost);
			// Decides if you win or lose
			if(guess > actualCost) {
				System.out.println("\nYour guess was over the correct amount; You lose!\nPlay Again? (Type \"YES\" if yes, type anything else if not)");
			} else if(guess < actualCost - 1300) {
				System.out.println("\nYour guess was off by more than $1300; You lose!\nPlay Again? (Type \"YES\" if yes, type anything else if not)");
			} else if(guess >= actualCost - 1300) {
				System.out.println("\nYour guess was within $1300 of the correct cost; You Win!\nPlay Again? (Type \"YES\" if yes, type anything else if not)");
			} 
			
			String again = keyboard.next();
			if (again.equals("YES")) {
				System.out.print("\n\n"); 
			} else {
				System.out.print("Goodbye!");
				playAgain = false;
			}
		}
	}
}
