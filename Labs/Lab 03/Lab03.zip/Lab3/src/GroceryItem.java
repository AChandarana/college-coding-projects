// Copyright 2025 Alex Chandarana
public class GroceryItem {

	private String name;
	private double value;

	public GroceryItem(String name, double value) {
		this.name = name;
		this.value = value;
	}

	public GroceryItem() {
		this.name = "none";
		this.value = 0;
	}
	
	public String getName(GroceryItem item) {
		return item.name;
	}
	
	public double getValue(GroceryItem item) {
		return item.value;
	}
	
	public String toString() {
		return "Grocery Item Name: " + name + " Value: " + value;
	}
	
	public boolean equals(GroceryItem item) { //learned to use 'this' for instances; fixed issue with printing memory addresses
		if(this.name.equals(item.name) && this.value == item.value) return true;
		return false;
	}
}
