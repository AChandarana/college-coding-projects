// Copyright 2025 Alex Chandarana
public class GroceryList {

	private class ListNode {
		GroceryItem item;
		ListNode link;
		public ListNode() {
			item = null;
			link = null;
		}
		public ListNode(GroceryItem aData, ListNode aLink) {
			item = aData;
			link = aLink;
		}
	}
	private ListNode head;
	private ListNode current;
	private ListNode previous;
	public GroceryList() {
		head = current = previous = null;
	}
	public void addItem(GroceryItem g) {
		if(g == null) return;
		ListNode newNode = new ListNode(g, null);
		if(head == null) {head = current = newNode; return;}
		ListNode temp = head;
		while(temp.link != null) temp = temp.link;
		temp.link = newNode;
	}
	
	public void addItemAfterCurrent(GroceryItem g) {
		if(g == null) return;
		if(head == null) return;
		ListNode newNode = new ListNode(g, current.link);
		current.link = newNode;
	}
	
	public void showList() {
		ListNode temp = head;
		while (temp != null) {
			System.out.println(temp.item.toString());
			temp = temp.link;
		}
		
	}

	public double totalCost() {
		double sum = 0;
		ListNode temp = head;
		while (temp != null) { //moves temp through 
			sum += temp.item.getValue(temp.item);
			temp = temp.link;
		}
		return sum;
	}

	public boolean contains(GroceryItem g) {
		ListNode temp = head;
		while(temp != null) { // moves temp through everything looking for something that matches
			if(temp.item.equals(g)) {
				return true;
			} else temp = temp.link;
		}
		return false;
	}

	public GroceryItem getCurrent() {
		if (current != null) return current.item;
		return null;
	}

	public void removeCurrent() {
		if(current == null) return;
		if(current == head) {
            head = head.link; // for head, moves head to the next in line
            current = head;
        } else {
            previous.link = current.link; //link to the previous now links to the link of the next in line, skipping over the current
            current = current.link;
        }
		
	}
	
	public void setCurrent(GroceryItem g) {
		current.item = g;
	}

	public void gotoNext() {
		previous = current;
		current = current.link;
		
	}

}
